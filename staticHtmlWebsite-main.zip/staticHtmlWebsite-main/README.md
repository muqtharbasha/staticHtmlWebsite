# staticHtmlWebsite
Static Html Website created for deploying and testing the application in various servers
